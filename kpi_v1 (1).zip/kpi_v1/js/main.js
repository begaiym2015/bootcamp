
$(window).ready(function(){//после загрузки window 
  render() //вызываем функцию render()
})

$('.btnAdd').on('click', function(e){
  e.preventDefault();
    let data = $('.add_form').serialize();

    $.ajax({
      method: 'post',
      url: "http://localhost:8000/students",
      data,
      success: render
    });
});

$('.openAddModal').on('click', function(){
  $('.add_modal').css('display','block')
});
$('.btnX').on('click', function(){
  $('.add_modal').css('display','none')
});
$('.add_modal').on('click',function(e){
  if(e.target !== e.currentTarget)return;
  $(this).css('display','none');
});

// -----------------------------------------------------------
let page = 1;
function render() {
  $.ajax({
      method: 'get',///?_page=${page}&_limit=6
      url: `http://localhost:8000/students/?_page=${page}&_limit=2`,
      success: function(data) {           
          $('.students_list').html('');
          data.forEach(item => {
              $('.students_list').append(`
                <li data-id="${item.id}" class="students">
                  <img data-id="${item.id}" src="${item.urlFoto}">
                  <span data-id="${item.id}">${item.fio}</span>
                </li>
              `);
          });
      }
  });
}
//----------------------------------------------------------------
$('.students_list').on('click', 'li', function(e){
  $('.student_modal').css('display','block')
  $('.student_form').text('');
  let target = $(e.target);
  let id = target.attr('data-id');
  $.ajax({
    method: 'get', 
    url: `http://localhost:8000/students/${id}`,
    success: function(data){
      $('.student_form').append(`
        <div class="btnX">x</div>
        <li class="liMod"></li>
        <li class="liMod">ФИО: <span data-what="fio" data-id="${data.id}">${data.fio}</span></li>
        <li class="liMod">Группа: <span data-what="group" data-id="${data.id}">${data.group}</span></li>
        <li class="liMod">KPI: <span data-what="kpi" data-id="${data.id}">${data.late}</span></li>
        <div class="modalDiv"><button class="btnDelete">Delete</button></div>
      `)
    }
  })
});
$('.student_form').on('click', '.btnX', function(){
  $('.student_modal').css('display','none')
});
$('.student_modal').on('click',function(e){
  if(e.target !== e.currentTarget)return;
  $(this).css('display','none');
});
//----------------------------------------------------------------------
$('.student_form').on('click', 'span', function(e){
  let target = $(e.target);
  let what = target.parent().attr('data-what');
  if(what==='kpi'){
    alert()
  }else{
    let text = $(e.target).text();
    target.html(`<input type="text" class="inpUpdate" value="${text}">`);
  }
});
$('.student_form').on('focusout', '.inpUpdate', function(e) {
  let target = $(e.target);
  let id = target.parent().attr('data-id');
  let result = target.val();
  let what = target.parent().attr('data-what');
  let data = {};
  data[what]=result;
  target.parent().html('').text(result);
  $.ajax({
      method: 'patch',
      url: `http://localhost:8000/students/${id}`,
      data,
      success: render
  });

  render();
});













